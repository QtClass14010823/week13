#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>

QWidget *myWindowPtr = nullptr;
QLineEdit *le1=nullptr;
QLineEdit *le2=nullptr;

void swapValue()
{
    QString strTemp=le1->text();
    le1->setText(le2->text());
    le2->setText(strTemp);
}
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget window;
    myWindowPtr=&window;
    window.setWindowTitle("First");
    QLineEdit lineEdit1(&window);
    QLineEdit lineEdit2(&window);

    le1=&lineEdit1;
    le2=&lineEdit2;

    QLabel label1("Value1", &window);
    QLabel label2("Value2", &window);

    label1.move(20, 40);
    label2.move(20, 80);



    lineEdit1.move(80,40);
    lineEdit2.move(80,80);
    lineEdit1.setText("1");
    lineEdit2.setText("2");


    QPushButton btnSwap("Swap Values",&window);
    QPushButton btnExit("Exit",&window);

    btnSwap.move(20,120);
    btnExit.move(120,120);

    QObject::connect(&btnSwap, &QPushButton::clicked, swapValue);

    QObject::connect(&btnExit, &QPushButton::clicked, &a,&QApplication::quit);

    window.show();

    return a.exec();
}

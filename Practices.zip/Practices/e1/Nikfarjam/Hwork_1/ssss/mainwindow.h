#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include<QPushButton>
#include<QGridLayout>
#include <QDebug>
#include <QWidget>
#include<QLineEdit>
#include<QLabel>


class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    QPushButton *btm1;
    QPushButton *btm2;
    QLineEdit *lnEdt1;
    QLineEdit *lnEdt2;
    QLabel *lbl1;
    QLabel *lbl2;
    QWidget *mainWidget;
    QGridLayout *mainGride;
    QString tmpStr;

private slots:
    void swapSlot();

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
};
#endif // MAINWINDOW_H

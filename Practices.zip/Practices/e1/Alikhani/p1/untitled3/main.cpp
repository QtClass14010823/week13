#include <QApplication>
#include <QtGui>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QWidget widget;


    QLabel label1 ("Value1 : ",&widget);
    label1.move(20,50);
    label1.show();
    QLabel label2 ("Value2 : ",&widget);
    label2.move(20,100);
    label2.show();

    QLineEdit *lineEdit1 = new QLineEdit ("123456789",&widget);
    lineEdit1->move(120,50);
    lineEdit1->show();
    QLineEdit *lineEdit2 = new QLineEdit("Hello",&widget);
    lineEdit2->move(120,100);
    lineEdit2->show();


    QPushButton btn1 ("Sawp\nValues",&widget);
    btn1.move(30,150);
    btn1.show();

    QObject::connect(&btn1, &QPushButton::clicked,&a, [=](){
        QString strLine11 = lineEdit1->text();
        QString strLine12 = lineEdit2->text();
        lineEdit1->setText(strLine12);
        lineEdit2->setText(strLine11);
    });


    QPushButton btn2 ("Exit\n",&widget);
    btn2.move(150,150);
    btn2.show();
    QObject::connect(&btn2, &QPushButton::clicked, &a, &QApplication::quit);

    widget.show();
    return a.exec();
}



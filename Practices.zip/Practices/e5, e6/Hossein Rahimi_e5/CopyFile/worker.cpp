#include "worker.h"
#include <QFile>
#include <QDebug>
#include <QApplication>>
#include "Form.h"

Worker::Worker(QObject *parent) : QObject(parent)
{

}

void Worker::doWork(const QString src_str,const QString dst_str)
{
    QFile in(src_str);
    QFile out(dst_str);
    char buff[100];
    quint64 readLen = 0;
    quint64 totalReadLen = 0;
    int percentage = 0 ,per_old=0;
    copy_pause=false;

    in.open(QIODevice::ReadOnly);
    out.open(QIODevice::WriteOnly);

//    this->setWindowTitle(QString("Copying 0%"));

    while(!in.atEnd())
    {

        //QApplication::processEvents();
        if(!copy_pause)
        {
            readLen = in.read(buff, sizeof(buff));
            totalReadLen += readLen;
            if (readLen > 0)
            {
                out.write(buff, readLen);
                percentage = (float)totalReadLen / (float)in.size() * 100;
                if(percentage != per_old)
                {
                     qDebug()<< QString("Copying %0%1").arg(percentage).arg("%");
                     per_old=percentage;
                }
             }
        }
      }

    out.close();
    in.close();

}

void Worker::doPuse(const bool cp_pause)
{
    copy_pause=cp_pause;
    if(cp_pause)
        qDebug()<< "Copy Workwer Thread Paused!";
    else
        qDebug()<< "Copy Workwer Thread Active";
}

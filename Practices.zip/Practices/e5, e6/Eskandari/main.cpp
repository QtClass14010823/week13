#include <iostream>
#include <QCoreApplication>
#include <QtConcurrent>
#include <QFuture>
#include <QVector>


QList<int> numberInterval(const int min, const int max)
{
    QList<int> temp;
    for (int i = min; i<=max; i++)
    {
        temp.append(i);
    }
    return temp;
}

bool mapPrimeNumber(const int & num)
{
    int counter =0;
    bool temp;
    for (int i = 1; i <= num; i++)
        {
            if (num % i == 0)
            {
               counter++;
            }
        }
        if (counter == 2)
        {
            temp = true;
        }
        else
        {
            temp = false;
        }
        return temp;
}

void reducePrimeNumber(int & totalPrime, const bool & isPrime)
{
    if (isPrime)
    {
        totalPrime ++;
    }
}

int main(int argc, char *argv[])
{
    int min = 3;
    int max = 18000;
    using namespace std;
    QCoreApplication a(argc, argv);
    QList<int> numInt = numberInterval(min,max);

    QFuture<int> f1;
    f1 = QtConcurrent::mappedReduced(numInt, mapPrimeNumber, reducePrimeNumber);
    f1.waitForFinished();
    int finalResult = f1.result();
    qDebug() << finalResult;

    return 0;
}

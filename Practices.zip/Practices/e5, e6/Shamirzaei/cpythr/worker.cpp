#include <QDebug>
#include <QThread>
#include "worker.h"

Worker::Worker(QObject *parent) : QObject(parent)
{
    this->parent = parent;
}

Worker::~Worker()
{
}

void Worker::doWork()
{
    QFile in(src);
    QFile out(dst);
    char buff[100];
    quint64 readLen = 0;
    quint64 totalReadLen = 0;
    int percentage = 0;

    in.open(QIODevice::ReadOnly);
    out.open(QIODevice::WriteOnly);

    while(!in.atEnd())
    {
        readLen = in.read(buff, sizeof(buff));
        totalReadLen += readLen;

        if (readLen > 0)
        {
            out.write(buff, readLen);
            percentage = (float)totalReadLen / (float)in.size() * 100;
        }
    }

    out.close();
    in.close();

}


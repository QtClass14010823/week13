#ifndef WORKER_H
#define WORKER_H

#include <QObject>
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QThread>
#include <QDebug>

class Worker : public QObject
{
    Q_OBJECT
public:
    explicit Worker(QObject *parent = nullptr);
    ~Worker();
    QString src,dst;
public slots:
    void doWork();
private:
    QObject *parent;
signals:

};

#endif // WORKER_H

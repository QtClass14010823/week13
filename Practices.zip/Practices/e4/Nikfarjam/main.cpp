#include "My_File.h"
#include"Test_Func.h"
#include <QApplication>

My_File *FilePtr=nullptr;

//#define TEST1

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    My_File w;
    w.show();

    FilePtr=&w;
#ifdef TEST1
  Test_Func MyTest;
  QTest::qExec(&MyTest);
#endif

    return a.exec();
}

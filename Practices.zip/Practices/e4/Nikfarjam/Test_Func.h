#ifndef TEST_FUNC_H
#define TEST_FUNC_H

#include <QObject>
#include<QtTest/QtTest>



class Test_Func : public QObject
{
    Q_OBJECT
public:
    explicit Test_Func(QObject *parent = nullptr);

signals:

private slots:
    void Test_My_Func();
    void Test_My_Func_Data();

};

#endif // TEST_FUNC_H

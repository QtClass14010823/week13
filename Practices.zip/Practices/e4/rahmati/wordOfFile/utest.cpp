#include "utest.h"
#include <QTest>
#include <Mainwindow.h>
#include <QMessageBox>

//extern MainWindow *mwPtr;


Utest::Utest(QObject *parent)
    : QObject{parent}
{
}
void Utest::wordCount_data()
{
    QTest::addColumn<QString>("fileName");
    QTest::addColumn<int>("wordCount");

    QFile file("input.txt");
    if(!file.exists())
    {
//        QMessageBox::critical(this,"Error","File not exists!!!",QMessageBox::Ok);
        return;
    }
    file.open(QIODevice::ReadOnly);
    QTextStream in(&file);
    int counter=0;
    QString strTmp;
    while (!in.atEnd())
    {
        in.readLineInto(&strTmp,300);
        strTmp=strTmp.simplified();
        if(strTmp.length()<3)   continue;//to avoid invalid string
        QStringList sl= strTmp.split(":");
        if(sl.count()<2)    continue;//to avoid not enough input

        QString strCaption="Case"+QString::number(++counter);
        QTest::newRow(strCaption.toLocal8Bit()) << sl.at(0).simplified()<< sl.at(1).simplified().toInt();
    }
    file.close();

//    QTest::newRow("no file") << "/home/user1/tt.txt" << -1;
//    QTest::newRow("1 word")     << "/home/user1/t1.txt" << 1;
//    QTest::newRow("2 word") << "/home/user1/t2.txt" << 2;


}
void Utest::wordCount()
{
    QFETCH(QString, fileName);
    QFETCH(int, wordCount);

    QCOMPARE(MainWindow::get_total_word(fileName), wordCount);
}


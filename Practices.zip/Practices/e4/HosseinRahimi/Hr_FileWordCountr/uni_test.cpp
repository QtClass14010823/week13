#include "uni_test.h"
#include "Form.h"

extern Form *frm_ptr;

void Uni_Test::w_counter_data()
{
    QTest::addColumn<QString>("string");
    QTest::addColumn<int>("result");

    QTest::newRow("Current Path") << "data.txt" <<13;
    QTest::newRow("Failure Name1") << "Data.txt" << -1;
    QTest::newRow("Failure Name2") << "data.tx" << -1;
}

void Uni_Test::w_counter()
{
    QFETCH(QString,string);
    QFETCH(int, result);
    QCOMPARE(frm_ptr->fileWordCounter(string),result);
}

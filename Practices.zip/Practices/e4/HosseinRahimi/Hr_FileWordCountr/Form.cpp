#include "Form.h"

#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <QDebug>
#include <QRegularExpression>

Form::Form(QWidget *parent) : QWidget(parent)
{
    fLayout = new QGridLayout(this);
    lblFname = new QLabel("File Phath:",this);
    lblInfo = new QLabel("Count = 0",this);
    lnEditName = new QLineEdit("data.txt",this);
    btnQuit = new QPushButton("Quit",this);

    fLayout->addWidget(lblFname,0,0);
    fLayout->addWidget(lnEditName,0,1);
    fLayout->addWidget(lblInfo,1,0);
    fLayout->addWidget(btnQuit,2,3);
    connect(btnQuit, &QPushButton::clicked, this, &Form::close);
    connect(lnEditName,&QLineEdit::returnPressed,this,&Form::onLineEnterPressed);
}

void Form::onLineEnterPressed(){
    int w_cntr;
    lblInfo->setText("Count = ?");
#ifdef Q_OS_LINUX
    QRegularExpression re("\\A\\w+"); //Start by 1 or more character word
//#elif  Q_OS_WINDOWS
#else
    QRegularExpression re("\\A\\w+:\\\w*"); //Start by 1 or more character word
#endif
    QRegularExpressionMatch match=re.match(lnEditName->text());
    if(match.hasMatch())
    {
        w_cntr=fileWordCounter(lnEditName->text());
        if(w_cntr!=-1)
            lblInfo->setText("Count = "+QString::number(w_cntr));
    }
    else
        QMessageBox::warning(this, "Information", "File String Not Correct!");
}

Form::~Form(){
 fp.close();
// QMessageBox::information(this, "Information", "Data.txt is closed.");
}

int Form::fileWordCounter(QString f_str)
{
    QString str;
    QStringList str_list;
    QFile fp1;
    fp1.setFileName(f_str);
    if(!fp1.exists())
        return -1;
    else
    {
        fp1.open(QIODevice::ReadOnly | QIODevice::Text);
        QTextStream fp_str(&fp1);
        str=fp_str.readAll();
        qDebug() << str;
        str_list = str.split(" ");
        str_list.removeAll("");
        qDebug() << str_list;
        return str_list.count();
    }
}

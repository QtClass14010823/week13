#ifndef FILE_OP_H
#define FILE_OP_H

typedef struct contactInfo{
    QString name;
    int tel;
}contactInfo;

void addContact(contactInfo in);
int countContact();
contactInfo findContact(QString name);

#endif // FILE_OP_H

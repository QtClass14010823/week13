#include <QApplication>
#include <QWidget>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include "file_op.h"

QLineEdit *sl_add_nameLE;
QLineEdit *sl_add_telLE;
QLineEdit *sl_find_nameLE;
QLabel *sl_contact_countv;

void addFunction(void)
{
    contactInfo temp;
    int count;
    temp.name = sl_add_nameLE->text();
    temp.tel = sl_add_telLE->text().toInt();
    addContact(temp);
    count = countContact();
    sl_contact_countv->setText(QString::number(count));
}

void findFunction(void)
{
    contactInfo temp;
    temp = findContact(sl_find_nameLE->text());
    if (!temp.name.isEmpty())
    {
        sl_add_nameLE->setText(temp.name);
        sl_add_telLE->setText(QString::number(temp.tel));
    }
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    int count=0;
    count=countContact();
    // Info Group Box
    QGroupBox *infoGB = new QGroupBox;
    infoGB->setTitle("Info");
    QHBoxLayout *info_layout = new QHBoxLayout;
    QLabel *contact_countL = new QLabel("Contact Count : ");
    QLabel *contact_countv = new QLabel(QString::number(count));
    sl_contact_countv = contact_countv;
    info_layout->addWidget(contact_countL);
    info_layout->addWidget(contact_countv);
    infoGB->setLayout(info_layout);

    // Add Group Box
    QGroupBox *addGB = new QGroupBox;
    addGB->setTitle("Add");
    QGridLayout *add_layout = new QGridLayout;
    QLabel *add_nameL = new QLabel("Name : ");
    QLabel *add_telL = new QLabel("Tel : ");
    QLineEdit *add_nameLE = new QLineEdit;
    QLineEdit *add_telLE = new QLineEdit;
    sl_add_nameLE = add_nameLE;
    sl_add_telLE = add_telLE;
    QPushButton *add_addPB = new QPushButton("Add");
    add_layout->addWidget(add_nameL,0,0,1,1);
    add_layout->addWidget(add_telL, 1,0,1,1);
    add_layout->addWidget(add_nameLE,0,1,1,1);
    add_layout->addWidget(add_telLE, 1,1,1,1);
    add_layout->addWidget(add_addPB,1,2,1,1);
    addGB->setLayout(add_layout);

    // Find Group Box
    QGroupBox *findGB = new QGroupBox;
    findGB->setTitle("Find");
    QHBoxLayout *find_layout = new QHBoxLayout;
    QLabel *find_nameL = new QLabel("Name : ");
    QLineEdit *find_nameLE = new QLineEdit;
    sl_find_nameLE = find_nameLE;
    QPushButton *find_findPB = new QPushButton("Find");
    find_layout->addWidget(find_nameL);
    find_layout->addWidget(find_nameLE);
    find_layout->addWidget(find_findPB);
    findGB->setLayout(find_layout);

    QVBoxLayout *main_layout = new QVBoxLayout;
    main_layout->addWidget(infoGB);
    main_layout->addWidget(addGB);
    main_layout->addWidget(findGB);

    QWidget *myWidget = new QWidget;
    myWidget->setLayout(main_layout);
    myWidget->show();

    QObject::connect(add_addPB, &QPushButton::clicked, addFunction);
    QObject::connect(find_findPB, &QPushButton::clicked, findFunction);

    return app.exec();
}

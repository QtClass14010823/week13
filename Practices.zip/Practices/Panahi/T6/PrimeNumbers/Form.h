#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QFuture>
#include <QFutureWatcher>

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtnStartClicked();
    void onTaskFinished();

private:
    QGridLayout *layout;
    QLabel *lblMin, *lblMax;
    QLineEdit *editMin, *editMax;
    QPushButton *btnStart;
    static QFuture<int> future;
    static QFutureWatcher<int> futureWatcher;

    QList<int> createListOfNumbers(int min, int max);
    static bool checkPrimeNumber(int n);
    static void reduce(int &result, const bool &n);
};

#endif // FORM_H

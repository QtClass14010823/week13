#include <QCoreApplication>

#include <iostream>

#include "SafeQueue.h"

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    SafeQueue sQueue;
    int ch;

    cout << "1) Insert element to queue." << endl;
    cout << "2) Delete element from queue." << endl;
    cout << "3) Display all the elements of queue." << endl;
    cout << "4) Exit." << endl;

    do
    {
        cout << "Enter your choice: ";
        cin >> ch;
        int n;

        switch (ch)
        {
            case 1:
                cout << "Enter number: ";
                cin >> n;
                if (sQueue.add(n))
                    cout << "Number added." << endl;
                else
                    cout << "Queue is full" << endl;
                break;
            case 2:
                if (sQueue.remove(&n))
                    cout << "Number is: " << n << endl;
                else
                    cout << "Queue is empty" << endl;
                break;
            case 3:
                sQueue.display();
                break;
            case 4:
                cout << "Exit" << endl;
                break;
            default:
                cout << "Invalid choice" << endl;
        }
    } while(ch != 4);

    return 0;
}

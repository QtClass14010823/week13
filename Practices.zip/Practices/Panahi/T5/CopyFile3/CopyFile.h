#ifndef COPYFILE_H
#define COPYFILE_H

#include <QObject>
#include <QEventLoop>

class CopyFile : public QObject
{
    Q_OBJECT

public:
    CopyFile(QObject *parent = nullptr);
    void startCopy(QString srcFile, QString dstFile);
    void toggleExecutionState(bool isSuspended);
	
signals:
    void progressChanged(int percent);
    void copyFinished();

private:
    QString srcFile;
    QString dstFile;
    bool isSuspended;
    bool startCopyIsRunning;
    QEventLoop loop;
};

#endif // COPYFILE_H

#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>

class Form : public QWidget
{
	Q_OBJECT
	
public:
    Form(QWidget *parent = Q_NULLPTR, Qt::WindowFlags f = Qt::WindowFlags());

private slots:
    void on_btnSwap_Clicked();

private:
    QGridLayout *layout;
    QLabel *lblText1, *lblText2;
    QLineEdit *editValue1, *editValue2;
    QPushButton *btnSwap;

    void swapValues(QString *s1, QString *s2);
};

#endif // FORM_H

#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGroupBox>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QRegularExpression>
#include <QRegularExpressionValidator>

class Form : public QWidget
{
    Q_OBJECT

friend class UnitTest;

public:
    Form(QWidget *parent = Q_NULLPTR, Qt::WindowFlags f = Qt::WindowFlags());

private slots:
    void on_textFilePath_returnPressed();
    void on_btnQuit_clicked();

private:
    QVBoxLayout *vLayout;
    QGridLayout *gLayout;
    QLabel *lblFilePath, *lblWordCountTitle, *lblWordCountValue;
    QLineEdit *textFilePath;
    QHBoxLayout *hLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *btnQuit;
    QRegularExpressionValidator regExpValidator;

    int wordCount(const QString filePath);
};

#endif // FORM_H

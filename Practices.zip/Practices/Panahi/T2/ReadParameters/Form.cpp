#include "Form.h"

Form::Form(QWidget *parent/* = Q_NULLPTR*/, Qt::WindowFlags f/* = Qt::WindowFlags()*/) :
    QWidget(parent, f)
{
}

void Form::initForm(QStringList *args)
{
    QGridLayout *layout = new QGridLayout(this);
    QLabel *lblParametersCountTitle = new QLabel("Parameters Count:", this);
    QLabel *lblParametersCountValue = new QLabel(this);
    QPushButton *btnClose = new QPushButton("Close", this);
    int counter = 0;

    layout->addWidget(lblParametersCountTitle, counter, 0);
    layout->addWidget(lblParametersCountValue, counter, 1);

    lblParametersCountTitle->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Maximum);
    lblParametersCountValue->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Maximum);
    lblParametersCountValue->setText(QString::number(args->count() - 1));
    lblParametersCountValue->setFrameShape(QFrame::Box);

    for (counter = 1; counter < args->count(); counter++)
    {
        //QLabel *lblText = new QLabel(QString("Parameter %0:").arg(counter), this);
        QLabel *lblText = new QLabel("Parameter " + QString::number(counter) + ":", this);
        QLineEdit *editParam = new QLineEdit(this);

        editParam->setText(args->at(counter));
        editParam->setReadOnly(true);

        layout->addWidget(lblText, counter, 0);
        layout->addWidget(editParam, counter, 1);
    }

    layout->addWidget(btnClose, counter, 1);

    this->setLayout(layout);

    connect(btnClose, &QPushButton::clicked, this, &Form::on_btnClose_Clicked);
}

void Form::on_btnClose_Clicked()
{
    close();
}

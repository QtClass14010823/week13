#include "Form.h"

#include <QFile>
#include <QFileDialog>
#include <QMessageBox>

Form::Form(QWidget *parent) :
    QWidget(parent),
	gLayout(this),
    NumberInCA(0)
{
    int i = 0;

    for (; i < THREAD_NUMBER; i++)
    {
        lblThreadText[i].setParent(this);
        lblThreadText[i].setText(QString("Thread %0:").arg(i + 1));

        lblThreadStatus[i].setParent(this);
        lblThreadStatus[i].setText("Normal.");

        gLayout.addWidget(&lblThreadText[i], i, 0);
        gLayout.addWidget(&lblThreadStatus[i], i, 1);
    }

    btnStart.setParent(this);
    btnStart.setText("Start");
    gLayout.addWidget(&btnStart, i, 1);

    this->setLayout(&gLayout);

    this->setWindowTitle("Calculating prime numbers");

    connect(&btnStart, &QPushButton::clicked, this, &Form::onStartClicked);
}

void Form::onStartClicked()
{
    this->setWindowTitle(QString("Number in the critical area: %0").arg(NumberInCA));

    for (int i = 0; i < THREAD_NUMBER; i++)
    {
        thread[i].setParent(this);
        thread[i].setParams(i, i * 100000, i * 100000 + 10000);
        connect(&thread[i], &PrimeNumbersThread::resourceUpdated, this, &Form::onResourceUpdated);
        thread[i].start();
    }
}

void Form::onResourceUpdated(int instance, bool isOccupied)
{
    if (isOccupied)
    {
        NumberInCA++;
        lblThreadStatus[instance].setText("Inside the critical area.");
    }
    else
    {
        NumberInCA--;
        lblThreadStatus[instance].setText("Normal.");
    }

    this->setWindowTitle(QString("Number in the critical area: %0").arg(NumberInCA));
}

#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGroupBox>
#include <QGridLayout>
#include <QVBoxLayout>

class Form : public QWidget
{
	Q_OBJECT
	
public:
    Form(QWidget *parent = Q_NULLPTR, Qt::WindowFlags f = Qt::WindowFlags());

private slots:
    void on_btnAdd_Clicked();
    void on_btnFind_Clicked();

private:
    struct ContactInfo
    {
        char name[20];
        int tel;

        ContactInfo()
        {
            memset(name, 0, sizeof(ContactInfo::name));
            tel = 0;
        }

        ContactInfo(const char *name, int tel)
        {
            if (strlen(name) >= sizeof(ContactInfo::name))
            {
                memcpy(this->name, name, sizeof(ContactInfo::name) - 1);
                this->name[sizeof(ContactInfo::name) - 1] = 0;
            }
            else
            {
                strcpy(this->name, name);
            }

            this->tel = tel;
        }
    };

    QVBoxLayout *vLayout;
    // Contact Info
    QGroupBox *grpBoxInfo;
    QHBoxLayout *contactInfoLayout;
    QLabel *lblContactCountTitle, *lblContactCountValue;

    // Add Contact
    QGroupBox *grpBoxAdd;
    QGridLayout *addLayout;
    QLabel *lblAddName, *lblAddTel;
    QLineEdit *editAddName, *editAddTel;
    QPushButton *btnAdd;

    // Find Contact
    QGroupBox *grpBoxFind;
    QHBoxLayout *findLayout;
    QLabel *lblFindName;
    QLineEdit *editFindName;
    QPushButton *btnFind;

    int getContactCount();
    bool appendContactToFile(ContactInfo contact);
    bool findContact(const QString name, int *tel);
};

#endif // FORM_H

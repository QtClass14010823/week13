#include "worker.h"

Worker::Worker(QObject *parent) : QObject(parent)
{
    this->parent = parent;
}

Worker::~Worker()
{
}

void Worker::setParams(QString name,int min,int max)
{
    this->min = min;
    this->max = max;
    this->name = name;
}

bool Worker::isPrime(int n)
{
    for(int i=2;i<=n/2;i++)
    {
        if(n%i == 0)
            return false;
     }
     return true;
}

QSemaphore FreeFileHandlers(3);

void Worker::doWork()
{
    int buf[50],i=0;
    for(int n=min;n<max;n++)
    {
        if(isPrime(n))
        {
            buf[i] = n;
            i++;
        }
        if(i==50 || n==max-1)
        {
            FreeFileHandlers.acquire();
            QFile file(name);
            file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text);
            QTextStream out(&file);
            for(int j=0;j<i;j++)
            {
                out<<buf[j]<<"\n";
            }
            file.close();
            FreeFileHandlers.release();
            i=0;
        }

    }
}


#ifndef MAINFORM_H
#define MAINFORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>
#include <CirQueue.h>

class MainForm : public QWidget
{
    Q_OBJECT
public:
    explicit MainForm(QWidget *parent = nullptr);
    ~MainForm();

signals:


private slots:
    void onAddClicked();
    void onDelClicked();

private:
    QGridLayout *bLayout;
    QLabel *lblAdd, *lblDel;
    QLineEdit *lnEditAdd, *lnEditDel;
    QPushButton *btnAdd, *btnDel;
    CirQueue *cirQueue;
};

#endif // MAINFORM_H

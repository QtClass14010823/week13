<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>Form</name>
    <message>
        <location filename="Form.cpp" line="34"/>
        <source>Title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Form.cpp" line="35"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Form.cpp" line="33"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Form.cpp" line="28"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

#include "LoginDlg.h"

#include <QDebug>

LoginDlg::LoginDlg(QWidget *parent) : QDialog(parent)
{
    vLayout = new QVBoxLayout(this);
    lnEditUser = new QLineEdit;
    lnEditPass = new QLineEdit;
    btnLogin = new QPushButton("Login");

    vLayout->addWidget(lnEditUser);
    vLayout->addWidget(lnEditPass);
    vLayout->addWidget(btnLogin);

    qDebug() << connect(btnLogin, &QPushButton::clicked, this, &LoginDlg::onLoginButtonClicked);
}

LoginDlg::DialogValues LoginDlg::getDialogValues()
{
    DialogValues result;

    result.user = lnEditUser->text();
    result.pass = lnEditPass->text();

    return result;
}

void LoginDlg::onLoginButtonClicked()
{
    this->accept();
    //this->reject();
}

#ifndef MAINWIN_H
#define MAINWIN_H

#include "LoginDlg.h"

#include <QWidget>
#include <QPushButton>

class MainWin : public QWidget
{
    Q_OBJECT
public:
    explicit MainWin(QWidget *parent = nullptr);

signals:

private slots:
    void onLoginButtonClicked();

private:
    QPushButton *loginBtn;
    LoginDlg loginDlg;
};

#endif // MAINWIN_H

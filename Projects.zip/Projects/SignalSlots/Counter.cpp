#include "counter.h"

#include <QDebug>

void Counter::setValue(int value)
{
    if (value != m_value) {
        m_value = value;
        emit valueChanged(value);

        if (value == 0)
            emit valueReset();
    }
}

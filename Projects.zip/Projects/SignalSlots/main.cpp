#include <QCoreApplication>
#include <QDebug>

#include "counter.h"

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    Counter a, b;

    QObject::connect(&a, &Counter::valueChanged, &b, &Counter::setValue);
    QObject::disconnect(&a, &Counter::valueChanged, &b, &Counter::setValue);

    //QObject::connect(&a, SIGNAL(valueChanged(int)), &b, SLOT(setValue(int)), Qt::QueuedConnection);
    QObject::connect(&a, SIGNAL(valueChanged(int)), &b, SLOT(setValue(int)));
    //QObject::connect(&a, &Counter::valueReset, &a, [=]() { qDebug() << "Value reseted."; });
    //QObject::disconnect(&a, SIGNAL(valueChanged(int)), &b, SLOT(setValue(int)));

    a.setValue(2);
    //a.setValue(0);
    //b.setValue(48);

    return app.exec();
}

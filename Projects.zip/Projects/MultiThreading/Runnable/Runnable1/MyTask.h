#ifndef MYTASK_H
#define MYTASK_H

#include <QThreadPool>
#include <QRunnable>

class MyTask : public QRunnable
{
protected:
    void run() override;
};

#endif // MYTASK_H

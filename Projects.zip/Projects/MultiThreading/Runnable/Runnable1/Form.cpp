#include "Form.h"

Form::Form(QWidget *parent) : QWidget(parent)
{
    layout = new QHBoxLayout(this);
    btn = new QPushButton("Counting numbers");

    layout->addWidget(btn);

    connect(btn, &QPushButton::clicked, this, &Form::onBtnClicked);
}

Form::~Form()
{
}

void Form::onBtnClicked()
{
    task = new MyTask;
    // QThreadPool takes ownership and deletes 'hello' automatically
    QThreadPool::globalInstance()->start(task);
}

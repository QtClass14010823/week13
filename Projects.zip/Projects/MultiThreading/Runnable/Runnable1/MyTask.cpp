#include "MyTask.h"

#include <QDebug>

void MyTask::run()
{
    /* ... here is the expensive or blocking operation ... */
    for (int i = 0; i < 10; i++)
    {
        qDebug() << i;

        QThread::sleep(1);
    }
}

#include "Form.h"

#include <QDebug>

Form::Form(QWidget *parent) : QWidget(parent),
    thread1("A", &mutex, this), thread2("B", &mutex, this), thread3("C", &mutex, this)
{
    layout = new QGridLayout(this);
    btnStart = new QPushButton("Start");

    layout->addWidget(btnStart);

    connect(btnStart, &QPushButton::clicked, this, &Form::onBtnStartClicked);
}

Form::~Form()
{
}

void Form::onBtnStartClicked()
{
    // thread start -> call run()
    thread1.start();
    thread2.start();
    thread3.start();
}


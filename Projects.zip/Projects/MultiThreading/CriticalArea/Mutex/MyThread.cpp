#include "MyThread.h"

#include <QDebug>

MyThread::MyThread(QString s, QMutex *mtx, QObject *parent) :
    QThread(parent),
    name(s),
    mutex(mtx)
{
}

// run() will be called when a thread starts
void MyThread::run()
{
    for(int i = 0; i <= 5; i++)
    {
        qDebug() << "Async: " << this->name << ": " << i;
    }

    // prevent other threads goto to tis section together
    mutex->lock();
    for(int i = 0; i <= 5; i++)
    {
        qDebug() << "Sync: " << this->name << ": " << i;
    }
    mutex->unlock();

    for(int i = 0; i <= 5; i++)
    {
        qDebug() << "Async: " << this->name << ": " << i;
    }
}

#include "Form.h"

#include <QDebug>
#include <QtConcurrent>
#include <QMessageBox>

QFuture<Form::WordCount> Form::future;
QFutureWatcher<Form::WordCount> Form::futureWatcher;

Form::Form(QWidget *parent) : QWidget(parent)
{
    layout = new QGridLayout(this);
    btnStart = new QPushButton("Start");
    btnPauseResume = new QPushButton("Pause/Resume");
    btnSingleThreadStart = new QPushButton("Single Thread Start");

    layout->addWidget(btnStart);
    layout->addWidget(btnPauseResume);
    layout->addWidget(btnSingleThreadStart);

    connect(btnStart, &QPushButton::clicked, this, &Form::onBtnStartClicked);
    connect(btnPauseResume, &QPushButton::clicked, this, &Form::onBtnPauseResume);
    connect(btnSingleThreadStart, &QPushButton::clicked, this, &Form::onBtnSingleThreadStartClicked);
    connect(&futureWatcher, &QFutureWatcher<QStringList>::finished, this, &Form::onTaskFinished);
}

Form::~Form()
{
}

void Form::onBtnStartClicked()
{
    QStringList files = findFiles("D:\\Temp\\Qt\\Projects\\Concurrent\\WordCount", QStringList() << "*.txt" << "*.gtxt");
    timer.start();
    future = QtConcurrent::mappedReduced(files, &Form::countWords, &Form::reduce);
    futureWatcher.setFuture(future);
}

void Form::onBtnPauseResume()
{
    //QMetaObject::invokeMethod(&Form::futureWatcher, "pause", Qt::AutoConnection);
    //QMetaObject::invokeMethod(&Form::futureWatcher, "resume", Qt::AutoConnection);

//    if (futureWatcher.isRunning())
//        futureWatcher.pause();
//    else
//        futureWatcher.togglePaused();

    future.togglePaused();
    //futureWatcher.togglePaused();
}

void Form::onBtnSingleThreadStartClicked()
{
    QStringList files = findFiles("D:\\Temp\\Qt\\Projects\\Concurrent\\WordCount", QStringList() << "*.txt" << "*.gtxt");
    quint64 singleThreadTime = 0;

    timer.start();
    WordCount total = singleThreadedWordCount(files);
    singleThreadTime = timer.elapsed();
    QMessageBox::information(this, "information", QString("Task is finished in %0 ms.").arg(singleThreadTime));
}

void Form::onTaskFinished()
{
    quint64 singleThreadTime = 0;

    singleThreadTime = timer.elapsed();
    QMessageBox::information(this, "information", QString("Task is finished in %0 ms.").arg(singleThreadTime));
}

/*
    Utility function that recursivily searches for files.
*/
QStringList Form::findFiles(const QString &startDir, const QStringList &filters)
{
    QStringList names;
    QDir dir(startDir);

    const auto files = dir.entryList(filters, QDir::Files);
    for (const QString &file : files)
        names += startDir + '/' + file;

    const auto subdirs =  dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot);
    for (const QString &subdir : subdirs)
        names += findFiles(startDir + '/' + subdir, filters);
    return names;
}

// countWords counts the words in a single file. This function is
// called in parallel by several threads and must be thread
// safe.
Form::WordCount Form::countWords(const QString &file)
{
    QFile f(file);
    f.open(QIODevice::ReadOnly);
    QTextStream textStream(&f);
    WordCount wordCount;

    while (!textStream.atEnd()) {
        const auto words =  textStream.readLine().split(' ');
        for (const QString &word : words)
            wordCount[word] += 1;
    }

    return wordCount;
}

// reduce adds the results from map to the final
// result. This functor will only be called by one thread
// at a time.
void Form::reduce(WordCount &result, const WordCount &w)
{
    for (auto i = w.begin(), end = w.end(); i != end; ++i)
    {
        result[i.key()] += i.value();
    }
}

/*
    Single threaded word counter function.
*/
Form::WordCount Form::singleThreadedWordCount(const QStringList &files)
{
    WordCount wordCount;
    for (const QString &file : files) {
        QFile f(file);
        f.open(QIODevice::ReadOnly);
        QTextStream textStream(&f);
        while (!textStream.atEnd()) {
            const auto words =  textStream.readLine().split(' ');
            for (const QString &word : words)
                wordCount[word] += 1;
        }
    }
    return wordCount;
}

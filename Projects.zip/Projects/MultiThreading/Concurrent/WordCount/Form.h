#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QGridLayout>
#include <QPushButton>
#include <QElapsedTimer>
#include <QStringList>
#include <QFuture>
#include <QFutureWatcher>

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtnStartClicked();
    void onBtnPauseResume();
    void onBtnSingleThreadStartClicked();
    void onTaskFinished();

private:
    typedef QMap<QString, int> WordCount;
    QElapsedTimer timer;
    QGridLayout *layout;
    QPushButton *btnStart, *btnPauseResume;
    QPushButton *btnSingleThreadStart;
    static QFuture<WordCount> future;
    static QFutureWatcher<WordCount> futureWatcher;

    QStringList findFiles(const QString &startDir, const QStringList &filters);
    static WordCount countWords(const QString &file);
    static void reduce(WordCount &result, const WordCount &w);
    WordCount singleThreadedWordCount(const QStringList &files);
};

#endif // FORM_H

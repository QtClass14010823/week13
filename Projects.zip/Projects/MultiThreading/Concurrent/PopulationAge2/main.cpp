#include <iostream>

#include <QCoreApplication>
#include <QDir>
#include <QTextStream>
#include <QtConcurrent>
#include <QFuture>
#include <QVector>

const int yearInterval = 5;

QStringList findFiles(const QString &dirPath, const QString &fileStart)
{
    QStringList filePaths;
    QDir dir(dirPath);

    foreach (QString file, dir.entryList(QDir::Files)){
        if(file.startsWith(fileStart))
            filePaths += dirPath + "/" + file;
    }

    return filePaths;
}

QVector<int> mapFile(const QString& fileName) {
    QFile file(fileName);
    file.open(QIODevice::ReadOnly);
    QTextStream in(&file);

    QVector<int> ageCounts;
    while (!in.atEnd()) {
        QString line = in.readLine();
        line = line.trimmed();
        if(!line.isEmpty()){
            bool iOk = false;
            int i = line.toInt(&iOk);
            if(iOk){
                int binNr = i / yearInterval;
                if(ageCounts.size() < binNr+1)
                    ageCounts.resize(binNr+1);
                ageCounts[binNr]++;
            }
        }
    }
    return ageCounts;
}

void reduce(QVector<int> &product,
                              const QVector<int> &ageCounts) {
    for(int i = 0; i < ageCounts.size(); i++){
        if(product.size() < ageCounts.size())
            product.resize(ageCounts.size());
        product[i]+= ageCounts.at(i);
    }
}

void drawCharacterHistogram(const QVector<int> &ageIntervals){
    for(int i = 0; i < ageIntervals.size(); i++)
    {
        if (ageIntervals[i] > 0)
        {
            std::cout << i * yearInterval << '-' << (i + 1) * yearInterval << ":\t";

            for (int j = 0; j < ageIntervals[i]; j++)
                std::cout << "#";

                std::cout << std::endl;
            }
    }
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QStringList filePaths = findFiles(QDir::currentPath(), "city");
    QFuture<QVector<int>> f1;
    f1 = QtConcurrent::mappedReduced(filePaths, mapFile, reduce);
    f1.waitForFinished();
    QVector<int> finalDistrib = f1.result();
    qDebug() << finalDistrib;
    drawCharacterHistogram(finalDistrib);

    return 0;
    //return a.exec();
}

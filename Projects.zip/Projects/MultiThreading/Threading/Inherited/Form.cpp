#include "Form.h"

Form::Form(QWidget *parent) : QWidget(parent)
{
    workerThread = new WorkerThread(this);
    layout = new QHBoxLayout(this);
    btn1 = new QPushButton("Counting numbers");
    btn2 = new QPushButton("Terminate");

    layout->addWidget(btn1);
    layout->addWidget(btn2);

    connect(btn1, &QPushButton::clicked, this, &Form::onBtn1Clicked);
    connect(btn2, &QPushButton::clicked, this, &Form::onBtn2Clicked);
    connect(workerThread, &WorkerThread::finished, this, &Form::onThreadFinished);
}

Form::~Form()
{
    if (workerThread->isRunning())
    {
        workerThread->wait();
        //workerThread->terminate();
    }

    delete workerThread; // Enable when "workerThread = new QThread;"
}

void Form::onBtn1Clicked()
{
    workerThread->start();
}

void Form::onBtn2Clicked()
{
    if (workerThread->isRunning())
    {
        workerThread->terminate();
    }
}

void Form::onThreadFinished()
{
}

#ifndef WORKERTHREAD_H
#define WORKERTHREAD_H

#include <QThread>

class WorkerThread : public QThread
{
    Q_OBJECT

public:
    WorkerThread(QObject *parent = nullptr) : QThread(parent)
    {
    }

protected:
    void run() Q_DECL_OVERRIDE;

signals:
};

#endif // WORKERTHREAD_H

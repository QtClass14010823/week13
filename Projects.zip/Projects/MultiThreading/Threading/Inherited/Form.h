#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QThread>
#include <QHBoxLayout>
#include <QPushButton>

#include "WorkerThread.h"

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtn1Clicked();
    void onBtn2Clicked();
    void onThreadFinished();

private:
    WorkerThread *workerThread;
    QHBoxLayout *layout;
    QPushButton *btn1, *btn2;
};

#endif // FORM_H

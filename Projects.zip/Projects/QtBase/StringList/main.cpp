#include <QCoreApplication>
#include <QStringList>
#include <QDebug>

#include <iostream>

using namespace std;

void f1()
{
    QStringList fonts = { "Arial", "Helvetica", "Times" };
    fonts << "Courier" << "Verdana";

    for (int i = 0; i < fonts.size(); ++i)
    cout << fonts.at(i).toLocal8Bit().constData() << endl;

    QStringListIterator javaStyleIterator(fonts);
    while (javaStyleIterator.hasNext())
    cout << javaStyleIterator.next().toLocal8Bit().constData() << endl;

    QStringList::const_iterator constIterator;
    for (constIterator = fonts.constBegin(); constIterator != fonts.constEnd(); ++constIterator)
        cout << (*constIterator).toLocal8Bit().constData() << endl;

    QString str = fonts.join(", ");
    // str == "Arial, Helvetica, Times, Courier"

    QStringList list;
    list = str.split(',');

    qDebug() << list;
}

void f2()
{
    QStringList files;
    files << "$QTDIR/src/moc/moc.y"
          << "$QTDIR/src/moc/moc.l"
          << "$QTDIR/include/qconfig.h";

    files.replaceInStrings("$QTDIR", "/usr/lib/qt");

    qDebug() << files;
}

void f3()
{
    QStringList list;
    list << "Bill Murray" << "John Doe" << "Bill Clinton";

    QStringList result;
    result = list.filter("Bill");
    // result: ["Bill Murray", "Bill Clinton"]

    foreach (const QString &str, list) {
        if (str.contains("Bill"))
            result += str;
    }

    qDebug() << result;
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    f1();

    f2();

    f3();

    return a.exec();
}

#include <QCoreApplication>
#include <QDir>
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // forward slash for directory separator
    QDir dir1("C:/Qt");
    QDir dir2("C:/Qt/test");

    // output: true false
    qDebug() << dir1.exists() << dir2.exists();

    return a.exec();
}

#include <QCoreApplication>
#include <QDir>
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // forward slash for directory separator
    QDir dir1("C:/Qt");
    QDir dir2("C:/Qt/test");
    qDebug() << dir1.exists() << dir2.exists();

    QDir dir3;
    foreach(QFileInfo item, dir3.drives() )
    {
        qDebug() << item.absoluteFilePath();
    }

    return a.exec();
}

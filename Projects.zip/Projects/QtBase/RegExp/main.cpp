#include <QApplication>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include <QValidator>
#include <QLineEdit>

#include <iostream>

using namespace std;

void f1()
{
    // match two digits followed by a space and a word
    QRegularExpression re("\\d\\d \\w+");
    QRegularExpressionMatch match = re.match("abc123 def");
    bool hasMatch = match.hasMatch(); // true
}

void f2()
{
    QRegularExpression re("\\d\\d \\w+");
    QRegularExpressionMatch match = re.match("abc123 def");

    if (match.hasMatch()) {
        QString matched = match.captured(0); // matched == "23 def"
        // ...
    }
}

void f3()
{
    QRegularExpression re("\\d\\d \\w+");
    QRegularExpressionMatch match = re.match("12 abc 45 def", 1);

    if (match.hasMatch()) {
        QString matched = match.captured(0); // matched == "45 def"
        // ...
    }
}

void f4()
{
    QRegularExpression re("^(\\d\\d)/(\\d\\d)/(\\d\\d\\d\\d)$");
    QRegularExpressionMatch match = re.match("08/12/1985");

    if (match.hasMatch()) {
        QString day = match.captured(1); // day == "08"
        QString month = match.captured(2); // month == "12"
        QString year = match.captured(3); // year == "1985"
        // ...
    }
}

void f5()
{
    QRegularExpression re("abc(\\d+)def");
    QRegularExpressionMatch match = re.match("XYZabc123defXYZ");

    if (match.hasMatch()) {
        int startOffset = match.capturedStart(1); // startOffset == 6
        int endOffset = match.capturedEnd(1); // endOffset == 9
        // ...
    }
}

void f6()
{
    QRegularExpression re("^(?<date>\\d\\d)/(?<month>\\d\\d)/(?<year>\\d\\d\\d\\d)$");
    QRegularExpressionMatch match = re.match("08/12/1985");

    if (match.hasMatch()) {
        QString date = match.captured("date"); // date == "08"
        QString month = match.captured("month"); // month == "12"
        QString year = match.captured("year"); // year == 1985
    }
}

void f7()
{
    QRegExp rx("(\\d+)");
    QString str = "Offsets: 12 14 99 231 7";
    QStringList list;
    int pos = 0;

    while ((pos = rx.indexIn(str, pos)) != -1) {
        list << rx.cap(1);
        pos += rx.matchedLength();
    }
    // list: ["12", "14", "99", "231", "7"]
}

void f8()
{
    QRegExp rx("^\\d\\d?$");    // match integers 0 to 99

    rx.indexIn("123");          // returns -1 (no match)
    rx.indexIn("-6");           // returns -1 (no match)
    rx.indexIn("6");            // returns 0 (matched at position 0)
}

void f9()
{
    QRegExp rx("^\\S+$");       // match strings without whitespace

    rx.indexIn("Hello world");  // returns -1 (no match)
    rx.indexIn("This_is-OK");   // returns 0 (matched at position 0)
}

void f10()
{
    QRegExp rx("\\b(mail|letter|correspondence)\\b");

    rx.indexIn("I sent you an email");     // returns -1 (no match)
    rx.indexIn("Please write the letter"); // returns 17

    QString captured = rx.cap(1); // captured == "letter"
}

void f11()
{
    QRegExp rx("&(?!amp;)");      // match ampersands but not &amp;
    QString line1 = "This & that";

    line1.replace(rx, "&amp;");
    // line1 == "This &amp; that"

    QString line2 = "His &amp; hers & theirs";

    line2.replace(rx, "&amp;");
    // line2 == "His &amp; hers &amp; theirs"
}

void f12()
{
    QString str = "One Eric another Eirik, and an Ericsson. "
                  "How many Eiriks, Eric?";
    QRegExp rx("\\b(Eric|Eirik)\\b"); // match Eric or Eirik
    int pos = 0;    // where we are in the string
    int count = 0;  // how many Eric and Eirik's we've counted

    while (pos >= 0) {
        pos = rx.indexIn(str, pos);
        if (pos >= 0) {
            ++pos;      // move along in str
            ++count;    // count our Eric or Eirik
        }
    }

    str = "The Qt Company Ltd\tqt.io\tFinland";
    QString company, web, country;

    rx.setPattern("^([^\t]+)\t([^\t]+)\t([^\t]+)$");

    if (rx.indexIn(str) != -1) {
        company = rx.cap(1);
        web = rx.cap(2);
        country = rx.cap(3);
    }
}

void f13()
{
    // regexp: optional '-' followed by between 1 and 3 digits
    QRegularExpression rx("-?\\d{1,3}");
    QValidator *validator = new QRegularExpressionValidator(rx, nullptr);
    QLineEdit *edit = new QLineEdit(nullptr);

    edit->setValidator(validator);
    edit->hasAcceptableInput();
    edit->show();
}

void f14()
{
    // integers 1 to 9999
    QRegularExpression re("[1-9]\\d{0,3}");
    // the validator treats the regexp as "^[1-9]\\d{0,3}$"
    QRegularExpressionValidator v(re, 0);
    QString s;
    int pos = 0;

    s = "0";     v.validate(s, pos);    // returns Invalid
    s = "12345"; v.validate(s, pos);    // returns Invalid
    s = "1";     v.validate(s, pos);    // returns Acceptable

    re.setPattern("\\S+");            // one or more non-whitespace characters
    v.setRegularExpression(re);
    s = "myfile.txt";  v.validate(s, pos); // Returns Acceptable
    s = "my file.txt"; v.validate(s, pos); // Returns Invalid

    // A, B or C followed by exactly five digits followed by W, X, Y or Z
    re.setPattern("[A-C]\\d{5}[W-Z]");
    v.setRegularExpression(re);
    s = "a12345Z"; v.validate(s, pos);        // Returns Invalid
    s = "A12345Z"; v.validate(s, pos);        // Returns Acceptable
    s = "B12";     v.validate(s, pos);        // Returns Intermediate

    // match most 'readme' files
    re.setPattern("read\\S?me(\.(txt|asc|1st))?");
    re.setPatternOptions(QRegularExpression::CaseInsensitiveOption);
    v.setRegularExpression(re);
    s = "readme";      v.validate(s, pos); // Returns Acceptable
    s = "README.1ST";  v.validate(s, pos); // Returns Acceptable
    s = "read me.txt"; v.validate(s, pos); // Returns Invalid
    s = "readm";       v.validate(s, pos); // Returns Intermediate
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    f1();
    f2();
    f3();
    f4();
    f5();
    f6();
    f7();
    f8();
    f9();
    f10();
    f11();
    f12();
    f13();
    f14();

    return a.exec();
}

#include <QCoreApplication>

#include <iostream>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    int n = 0;

    std::cin >> n;

    std::cout << n * 2;

    return 0;
}

#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>
#include <QProcess>

class Form : public QWidget
{
public:
    Form(QWidget *parent = Q_NULLPTR, Qt::WindowFlags f = Qt::WindowFlags());

private slots:
    void on_BtnExecutablePath_Clicked();
    void on_BtnRunProc1_Clicked();
    void on_BtnRunProc2_Clicked();
    void on_BtnRunProc3_Clicked();
    void on_BtnRunProc4_Clicked();
    void on_BtnRunProc5_Clicked();
    void on_BtnRunProc6_Clicked();
    void on_Process_Finished(int exitCode, QProcess::ExitStatus exitStatus);

private:
    QGridLayout *layout;
    QLabel *lblExecutableTitle, *lblExecutablePath;
    QPushButton *btnExecutablePath;
    QLabel *lblParam1, *lblParam2;
    QLineEdit *editParam1, *editParam2;
    QPushButton *btnRunProc1;
    QPushButton *btnRunProc2;
    QPushButton *btnRunProc3;
    QPushButton *btnRunProc4;
    QPushButton *btnRunProc5;
    QPushButton *btnRunProc6;

    QProcess process;
};

#endif // FORM_H

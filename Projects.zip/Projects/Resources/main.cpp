#include <QCoreApplication>

#include <iostream>

#include <QDebug>
#include <QFile>
#include <QResource>

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    int choice;

    cout << "Enter 1 to load internal resource or 2 to load external resource: ";
    cin >> choice;

    QFile file;

    if (choice == 1)
    {
        file.setFileName(":/myresources/File.txt");
    }
    else if (choice == 2)
    {
        QResource::registerResource("C:\\Users\\root\\Desktop\\Resources\\Resources\\external.rcc");
        file.setFileName(":/myresources/Files/Note.txt");
    }
    else
    {
        return 1;
    }

    file.open(QIODevice::ReadOnly);
    qDebug() << file.readAll();
    file.close();

    return 0;
}

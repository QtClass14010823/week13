#ifndef TEST_H
#define TEST_H

#include <QtTest>

class TestFooClass: public QObject
{
    Q_OBJECT
private slots:
    void test_func_foo();
};

class TestBarClass: public QObject
{
    Q_OBJECT
private slots:
    void test_func_bar();
};

#endif // TEST_H

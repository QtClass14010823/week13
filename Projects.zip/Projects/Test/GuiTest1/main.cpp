#include <QtTest>

#include "GuiTest.h"

QTEST_MAIN(TestGui)

#include <QtTest>

#include "TestQString.h"

QTEST_MAIN(TestQString)

#include <iostream>

using namespace std;

int main()
{
    int *intPtr = new int;

    *intPtr = 7;

    cout << *intPtr << endl;
	
	// Forget to free intPtr

    return 0;
}

#include <iostream>

using namespace std;

class String
{
private:
    char* text;

public:
    /*explicit*/ String(const char* text = nullptr)
    {
        this->text = new char[100]{ 0, };

        if (text)
        {
            strcpy(this->text, text);
        }
    }

    ~String()
    {
        delete[] text;
    }

    String(const String& string)
    {
        cout << "Copy.\n";
        text = new char[100]{ 0, };
        strcpy(text, string.text);
    }

    // Define copy assignment operator.
    String& operator=(const String& string)
    {
        strcpy(text, string.text);

        // Assignment operator returns left side of assignment.
        return *this;
    }

    void setText(const char* text)
    {
        strcpy(this->text, text);
    }

    char* getText()
    {
        return text;
    }
};

String foo()
{
    //String s("salam");
    //return s;

    return String("salam");
}

int main()
{
    String h = foo();
    String s1("t1");
    String s2 = "t2";
    String s3 = s2;
    String s4 = String("t3");
    s1 = s2;

    s1.setText("Ali.\n");
    s2.setText("Sajad.\n");

    cout << s1.getText();
    cout << s2.getText();

    return 0;
}